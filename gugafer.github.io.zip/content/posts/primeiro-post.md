---
title: "Boas-vindas ao meu blog!"
date: 2025-06-21
draft: false
tags: ["cloud", "devops", "blog"]
---

Este é o primeiro post do meu novo blog hospedado no GitHub Pages usando Hugo com o tema PaperMod.

Neste espaço, vou compartilhar dicas, tutoriais, experiências e reflexões sobre **Cloud Computing**, **DevOps**, **automação**, **certificações** e muito mais.

Fique à vontade para explorar os conteúdos e me acompanhar nessa jornada! 🚀
