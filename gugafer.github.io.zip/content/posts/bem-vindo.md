---
title: "Boas-vindas ao meu blog!"
date: 2025-06-22T19:00:00
draft: false
tags: ["Boas-vindas", "Hugo", "PaperMod"]
categories: ["Apresentação"]
description: "Primeiro post do blog pessoal com Hugo e PaperMod"
cover:
  image: "/images/hugo-welcome.jpg"
  alt: "Bem-vindo ao blog Hugo"
  caption: "Imagem gerada com IA como capa do post de boas-vindas"
  relative: true
---
Seja bem-vindo ao meu blog pessoal! Aqui pretendo compartilhar experiências sobre cloud computing, DevOps, automação com IaC, certificações e muito mais.

Esse primeiro post serve para validar toda a configuração do meu blog com o tema **PaperMod**, hospedado no **GitHub Pages** com **CI/CD via GitHub Actions**.

Acompanhe os próximos conteúdos!
